from sqlalchemy.orm import Session
from sqlalchemy import select, delete
from fastapi import HTTPException
from sqlalchemy.exc import IntegrityError

from backend.app.models.member import Member
from backend.app.models.restrictions.item import Item
from backend.app.models.restrictions.dislike import Dislike
from backend.app.models.restrictions.member_restriction import MemberRestrictions

# password hash 작업
from backend.app.core.security.password import hash_password

import json

# 등록
def create_member(db: Session, payload) -> None:
    # db.begin() :: commit, rollback 둘중 처리
    print(payload)

    # password 변경 작업 추가 예정

    try:
        member_data = payload.model_dump(exclude={"item_ids", "dislike_tags"})
        member_data["password"] = hash_password(member_data["password"])

        member = Member(**member_data)
        db.add(member)
        db.flush()  # member_id 확보

        member_id = member.member_id

        # item_ids
        if payload.item_ids:
            req_ids = set(payload.item_ids)
            found = set(
                db.execute(select(Item.item_id).where(Item.item_id.in_(req_ids))).scalars().all()
            )
            missing = sorted(req_ids - found)
            if missing:
                raise HTTPException(400, detail={"message": "invalid item_ids", "missing_item_ids": missing})

            db.add_all([MemberRestrictions(member_id=member_id, item_id=i) for i in sorted(req_ids)])

        # dislike_tags
        if payload.dislike_tags:
            tag_json = json.dumps(payload.dislike_tags, ensure_ascii=False)
            db.add(Dislike(member_id=member_id, dislike_tag=tag_json))

        db.commit()
        db.refresh(member)
        return member

    except IntegrityError:
        db.rollback()
        raise HTTPException(409, detail="duplicate key")
    except HTTPException:
        db.rollback()
        raise
    except Exception:
        db.rollback()
        raise

# 조회
def get_member(db: Session, member_id: int) -> dict:
    print(member_id)

    m = db.get(Member, member_id)
    if not m:
        raise HTTPException(status_code=404, detail="Member not found")

    item_ids = db.execute(
        select(MemberRestrictions.item_id).where(MemberRestrictions.member_id == member_id)
    ).scalars().all()

    tag_raw = db.execute(
        select(Dislike.dislike_tag).where(Dislike.member_id == member_id)
    ).scalar_one_or_none()
    print("tag_raw :: ", tag_raw)

    # dislike_tags = None
    # if tag_raw is not None:
    #     # DB에 JSON 문자열로 저장했으니 리스트로 복원
    #     dislike_tags = json.loads(tag_raw)

    dislike_tags = None
    if tag_raw is not None:
        try:
            dislike_tags = json.loads(tag_raw)
        except Exception:
            dislike_tags = [tag_raw]  # 혹시 그냥 문자열이면 방어

    return {
        "member_id": m.member_id,
        "email": m.email,
        "nickname": m.nickname,
        "gender": m.gender,
        "country": m.country,
        "role": m.role,
        "item_ids": item_ids,
        "dislike_tags": dislike_tags,
    }

# 수정
def update_member(db: Session, member_id: int, payload):

    print("update member :: ", payload)

    try:
        m = db.get(Member, member_id)
        if not m:
            raise HTTPException(404, detail="Member not found")

        # nickname 변경(필요 시 유니크 체크)
        if payload.nickname is not None and payload.nickname != m.nickname:
            exists = db.execute(
                select(Member.member_id).where(
                    Member.nickname == payload.nickname,
                    Member.member_id != member_id
                )
            ).scalar_one_or_none()
            if exists is not None:
                raise HTTPException(409, detail="nickname already exists")
            m.nickname = payload.nickname

        # item_ids: None=변경없음 / []=전체해제 / [..]=replace
        if payload.item_ids is not None:
            new_ids = set(payload.item_ids)
            old_ids = set(
                db.execute(
                    select(MemberRestrictions.item_id).where(MemberRestrictions.member_id == member_id)
                ).scalars().all()
            )

            if new_ids != old_ids:
                if new_ids:
                    found = set(
                        db.execute(select(Item.item_id).where(Item.item_id.in_(new_ids))).scalars().all()
                    )
                    missing = sorted(new_ids - found)
                    if missing:
                        raise HTTPException(
                            400,
                            detail={"message": "invalid item_ids", "missing_item_ids": missing},
                        )

                db.execute(delete(MemberRestrictions).where(MemberRestrictions.member_id == member_id))
                if new_ids:
                    db.add_all(
                        [MemberRestrictions(member_id=member_id, item_id=i) for i in sorted(new_ids)]
                    )

        # dislike_tags: None=변경없음 / []=비우기 / [..]=업데이트
        if payload.dislike_tags is not None:
            # []면 삭제
            if len(payload.dislike_tags) == 0:
                db.execute(delete(Dislike).where(Dislike.member_id == member_id))
            else:
                # 리스트 -> JSON 문자열로 저장
                tag_json = json.dumps(payload.dislike_tags, ensure_ascii=False)

                c = db.execute(select(Dislike).where(Dislike.member_id == member_id)).scalar_one_or_none()
                if c:
                    c.dislike_tag = tag_json
                else:
                    db.add(Dislike(member_id=member_id, dislike_tag=tag_json))

        # commit / refresh
        db.commit()
        db.refresh(m)
        return m

    except IntegrityError:
        db.rollback()
        raise HTTPException(409, detail="duplicate key")
    except HTTPException:
        db.rollback()
        raise
    except Exception:
        db.rollback()
        raise


# 삭제
def delete_member(db: Session, member_id: int) -> None:
    try:
        m = db.get(Member, member_id)
        if not m:
            raise HTTPException(status_code=404, detail="Member not found")

        # 추가적인 img 삭제 로직 추가 가능성

        db.delete(m)
        db.commit()
        return

    except HTTPException:
        db.rollback()
        raise
    except Exception:
        db.rollback()
        raise


# NickName 체크 로직 // True / False
def is_nickname_available(db: Session, nickname: str) -> bool:

    exists = db.execute(
        select(Member.member_id).where(Member.nickname == nickname)
    ).scalar_one_or_none()

    return exists is None