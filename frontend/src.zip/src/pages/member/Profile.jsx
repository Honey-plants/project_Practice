import React, { useContext, useEffect, useState, useMemo, useRef } from "react";
import { MemberContext } from "../../context/MemberContext";
import { ReviewContext } from "../../context/ReviewContext";
import { CommunityContext } from "../../context/CommunityContext";
import ProfileSidebar from "../../components/profile/ProfileSidebar";
import RestrictionsSection from "../../components/profile/RestrictionsSection";
import ReviewSection from "../../components/profile/ReviewSection";
import CommunitySection from "../../components/profile/CommunitySection";
import styles from "./Profile.module.css";

/**
 * Profile
 * 1) 본인 정보 노출 (왼쪽 사이드바)
 * 2) 본인이 선택한 item_ids만 "읽기 전용"으로 표시
 * 3) 내가 작성한 리뷰 목록
 * 4) 내가 작성한 커뮤니티 글 목록
 */
export default function Profile() {
  const { stateMember, memberActions } = useContext(MemberContext);
  const { stateReview, reviewActions } = useContext(ReviewContext);
  const { stateCommunity, communityActions } = useContext(CommunityContext);

  const [reviewPage, setReviewPage] = useState(0);
  const [communityPage, setCommunityPage] = useState(0);

  const me = stateMember.me;

  // ✅ me 로드 중복 방지(이 페이지에서만) - 선택사항
  // MemberProvider가 이미 자동 로드하지만,
  // 새로고침/직접진입에서 me가 비어있을 때만 "한 번" 보조 호출
  const requestedMeRef = useRef(false);

  // 내가 선택한 item_ids
  const selectedIds = useMemo(() => (me?.item_ids ? me.item_ids : []), [me]);

  // ✅ 수정 포인트 A) me가 없을 때만(그리고 한 번만) loadMe 시도
  useEffect(() => {
    if (me) return;
    if (stateMember.loading) return;
    if (requestedMeRef.current) return;

    requestedMeRef.current = true;
    memberActions?.loadMe?.();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [me, stateMember.loading]);

  // ✅ 수정 포인트 B) 리뷰/커뮤니티는 me 준비된 뒤(=인증 준비된 뒤) 호출
  useEffect(() => {
    if (!me?.member_id) return;

    // fetchMyList가 서버에서 "내 글만" 내려주는 API면 필터링 불필요.
    // 반대로 전체 list 내려주면 여기서 member_id로 필터링 해야 함.
    reviewActions.fetchMyList({ page: reviewPage });
    communityActions.fetchMyList({ page: communityPage });

    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [me?.member_id, reviewPage, communityPage]);

  // ✅ 안전 처리: list가 없을 수 있음
  const myReviews = useMemo(() => stateReview.list ?? [], [stateReview.list]);

  const myCommunities = useMemo(() => {
    const list = stateCommunity.list ?? [];
    // fetchMyList가 진짜 "내 글만" 내려주면 아래 filter는 없어도 됨
    return list.filter((community) => community.member_id === me?.member_id);
  }, [stateCommunity.list, me?.member_id]);

  if (!me) {
    return (
      <div className={styles.loading}>
        <p>로딩 중...</p>
      </div>
    );
  }

  return (
    <div className={styles.container}>
      <div className={styles.grid}>
        {/* 왼쪽: 회원 정보 사이드바 */}
        <ProfileSidebar member={me} />

        {/* 오른쪽: 메인 콘텐츠 */}
        <div>
          {/* 에러 메시지 */}
          {stateMember?.error && <div className={styles.error}>{stateMember.error}</div>}

          {/* 내가 선택한 제한 아이템 섹션 */}
          <RestrictionsSection selectedIds={selectedIds} />

          {/* 내가 작성한 리뷰 섹션 */}
          <ReviewSection
            reviews={myReviews}
            currentPage={reviewPage}
            onPageChange={setReviewPage}
          />

          {/* 내가 작성한 커뮤니티 글 섹션 */}
          <CommunitySection
            communities={myCommunities}
            currentPage={communityPage}
            onPageChange={setCommunityPage}
          />
        </div>
      </div>
    </div>
  );
}
