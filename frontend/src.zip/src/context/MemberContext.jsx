import React, { createContext, useContext, useEffect, useReducer, useMemo, useRef } from "react";
import { MemberAPI } from "../api/memberApi";
import { AuthContext } from "./AuthContext";

export const MemberContext = createContext(null);

const initial = {
  me: null,
  loading: false,
  error: "",
};

function reducer(state, action) {
  switch (action.type) {
    case "LOADING":
      return { ...state, loading: true, error: "" };
    case "SET_ME":
      return { ...state, me: action.payload, loading: false, error: "" };
    case "ERROR":
      return { ...state, loading: false, error: action.payload || "error" };
    case "CLEAR":
      return { ...initial };
    default:
      return state;
  }
}

export function MemberProvider({ children }) {
  const { stateAuth } = useContext(AuthContext);
  const [stateMember, dispatch] = useReducer(reducer, initial);

  // 중복 호출 방지용
  const lastTokenRef = useRef(null);   // 마지막으로 me를 불러온 토큰
  const inflightRef = useRef(null);    // 현재 loadMe 진행 중인 Promise

  // memberActions를 useMemo로 고정 (참조 안정화)
  const memberActions = useMemo(() => {
    const loadMe = async () => {
      dispatch({ type: "LOADING" });
      try {
        const r = await MemberAPI.me();
        dispatch({ type: "SET_ME", payload: r.data });
        return r.data;
      } catch (e) {
        dispatch({ type: "ERROR", payload: e.message });
        return null;
      }
    };

    const updateMe = async (payload) => {
      dispatch({ type: "LOADING" });
      try {
        await MemberAPI.updateMe(payload);
        return await loadMe();
      } catch (e) {
        dispatch({ type: "ERROR", payload: e.message });
        throw e;
      }
    };

    const clear = () => dispatch({ type: "CLEAR" });

    return { loadMe, updateMe, clear };
  }, []);
  useEffect(() => {
    const token = stateAuth?.accessToken;

    // 토큰 없으면 초기화 + ref 리셋
    if (!token) {
      lastTokenRef.current = null;
      inflightRef.current = null;
      memberActions.clear();
      return;
    }

    // 동일 토큰이면 다시 호출하지 않음
    if (lastTokenRef.current === token) return;

    // 이미 loadMe가 진행 중이면 또 호출하지 않음
    if (inflightRef.current) return;

    lastTokenRef.current = token;

    // 1회만 실행
    inflightRef.current = (async () => {
      try {
        await memberActions.loadMe();
      } finally {
        inflightRef.current = null;
      }
    })();

    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [stateAuth.accessToken]);

  return (
    <MemberContext.Provider value={{ stateMember, memberActions }}>
      {children}
    </MemberContext.Provider>
  );
}